/*global initBase, initApp, showInfo, showStatus, registerKeyEventListener, GLOB, VK_RED */

var cycleShort = 10;
var cycleLong = 60;
var appStart = new Date();
var loadedShort = false;
var loadedLong = false;
var confirmMsg = 0;
var testAborted = false;

function updateLoaded() {
  if (testAborted) {
    return;
  }
  if (loadedShort && confirmMsg===0) {
    confirmMsg = 1;
    showInfo("Press VK_RED to confirm that application loading time from channel change until now (time when this message was displayed) was not more than "+(cycleShort*2)+" seconds. If time was longer, the test failed!");
    registerKeyEventListener(function(kc) {
      if (kc!==VK_RED) {
        return false;
      }
      confirmMsg = 2;
      showInfo("Loading time confirmed."+(loadedLong?"":" Waiting until long cycle image is loaded..."));
      updateLoaded();
      return true;
    });
    return;
  }
  if (loadedShort && loadedLong && confirmMsg===2) {
    showStatus(1, "Image load timing is correct.");
  }
}

function init() {
  initBase();
  initApp(false);
  showInfo("Checking image load times...");
  try {
    GLOB.logoOuter.removeChild(GLOB.logoInner);
    GLOB.logoInner = document.createElement("img");
    GLOB.logoInner.className = "logoinner";
    GLOB.logoInner.onload = function() {
      var now = new Date();
      var loadms = now.getTime()-appStart.getTime();
      if (loadms>cycleShort*2000) {
        showStatus(0, "Short cycle image loading took too long: "+loadms+"ms, but cycle time is "+cycleShort+" seconds");
        testAborted = true;
        return;
      }
      loadedShort = true;
      showInfo("Short cycle image was loaded after "+loadms+"ms");
      updateLoaded();
    };
    GLOB.logoInner.src = "logo.png";
    GLOB.logoOuter.appendChild(GLOB.logoInner);
  } catch (err1) {
    showStatus(0, "Loading first image (short cycle) failed: "+err1);
  }

  try {
    GLOB.bigimg = document.createElement("img");
    GLOB.bigimg.style.position = "absolute";
    GLOB.bigimg.style.left = "880px";
    GLOB.bigimg.style.top = "220px";
    GLOB.bigimg.style.width = "320px";
    GLOB.bigimg.style.height = "auto";
    GLOB.bigimg.onload = function() {
      var now = new Date();
      var loadms = now.getTime()-appStart.getTime();
      if (loadms>cycleLong*2000) {
        showStatus(0, "Long cycle image loading took too long: "+loadms+"ms, but cycle time is "+cycleLong+" seconds");
        testAborted = true;
        return;
      }
      if (loadms<cycleShort*1000 && !GLOB.demo) {
        showStatus(0, "Long cycle image loading was too fast ("+loadms+"ms), cycle time is "+cycleLong+" seconds, so image was loaded from cache. Clear carousel cache (e.g. by resetting device) and try again");
        testAborted = true;
        return;
      }
      loadedLong = true;
      showInfo("Long cycle image was loaded after "+loadms+"ms");
      updateLoaded();
    };
    GLOB.bigimg.src = "bigimg.jpg";
    GLOB.app.appendChild(GLOB.bigimg);
  } catch (err2) {
    showStatus(0, "Loading second image (long cycle) failed: "+err2);
  }

  setTimeout(function() {
    if (testAborted || (loadedShort && loadedLong)) {
      return;
    }
    testAborted = true;
    showStatus(0, "Image loading timed out after "+(cycleLong*2)+" seconds, test failed.");
  }, cycleLong*2000);
}

