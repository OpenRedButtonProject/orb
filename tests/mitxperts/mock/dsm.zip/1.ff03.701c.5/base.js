/*global KeyEvent, releaseinfo, settings */

if (typeof(KeyEvent)!='undefined') {
  if (typeof(KeyEvent.VK_LEFT)!='undefined') {
    var VK_LEFT = KeyEvent.VK_LEFT;
    var VK_UP = KeyEvent.VK_UP;
    var VK_RIGHT = KeyEvent.VK_RIGHT;
    var VK_DOWN = KeyEvent.VK_DOWN;
  }
  if (typeof(KeyEvent.VK_ENTER)!='undefined') {
    var VK_ENTER = KeyEvent.VK_ENTER;
  }
  if (typeof(KeyEvent.VK_RED)!='undefined') {
    var VK_RED = KeyEvent.VK_RED;
    var VK_GREEN = KeyEvent.VK_GREEN;
    var VK_YELLOW = KeyEvent.VK_YELLOW;
    var VK_BLUE = KeyEvent.VK_BLUE;
  }
  if (typeof(KeyEvent.VK_BACK)!='undefined') {
    var VK_BACK = KeyEvent.VK_BACK;
  }
  if (typeof(KeyEvent.VK_0)!='undefined') {
    var VK_0 = KeyEvent.VK_0;
    var VK_1 = KeyEvent.VK_1;
    var VK_2 = KeyEvent.VK_2;
    var VK_3 = KeyEvent.VK_3;
    var VK_4 = KeyEvent.VK_4;
    var VK_5 = KeyEvent.VK_5;
    var VK_6 = KeyEvent.VK_6;
    var VK_7 = KeyEvent.VK_7;
    var VK_8 = KeyEvent.VK_8;
    var VK_9 = KeyEvent.VK_9;
  }
}
if (typeof(VK_LEFT)=='undefined') {
  var VK_LEFT = 0x25;
  var VK_UP = 0x26;
  var VK_RIGHT = 0x27;
  var VK_DOWN = 0x28;
}
if (typeof(VK_ENTER)=='undefined') {
  var VK_ENTER = 0x0d;
}
if (typeof(VK_RED)=='undefined') {
  var VK_RED = 0x74;
  var VK_GREEN = 0x75;
  var VK_YELLOW = 0x76;
  var VK_BLUE = 0x77;
}
if (typeof(VK_BACK)=='undefined') {
  var VK_BACK = 0xa6;
}
if (typeof(VK_0)=='undefined') {
  var VK_0 = 0x30;
  var VK_1 = 0x31;
  var VK_2 = 0x32;
  var VK_3 = 0x33;
  var VK_4 = 0x34;
  var VK_5 = 0x35;
  var VK_6 = 0x36;
  var VK_7 = 0x37;
  var VK_8 = 0x38;
  var VK_9 = 0x39;
}

var GLOB = {};

function initBase() {
  GLOB.app = document.getElementById("app");
  GLOB.logoOuter = document.createElement("div");
  GLOB.logoOuter.className = "logoouter";
  GLOB.logoInner = document.createElement("div");
  GLOB.logoInner.className = "logoinner";
  GLOB.logoOuter.appendChild(GLOB.logoInner);
  GLOB.logoTxt = document.createElement("div");
  GLOB.logoTxt.className = "logotxt";
  GLOB.logoTxt.innerHTML = "ARD DTVP HbbTV Tests";
  GLOB.logoOuter.appendChild(GLOB.logoTxt);
  GLOB.logoRel = document.createElement("div");
  GLOB.logoRel.className = "logorel";
  GLOB.logoRel.innerHTML = "Release: "+releaseinfo;
  GLOB.logoOuter.appendChild(GLOB.logoRel);
  GLOB.app.appendChild(GLOB.logoOuter);
  GLOB.status = document.createElement("div");
  GLOB.status.className = "status";
  GLOB.status.innerHTML = "<p class=\"title\">TEST: "+GLOB.testname+"</p><p>Test status:</p>";
  GLOB.app.appendChild(GLOB.status);
}

function initApp(regKeys) {
  try {
    var app = document.getElementById("appmgr").getOwnerApplication(document);
    app.show();
    app.activate(); // this is for HbbTV 0.5 backwards-compliance. It will throw an ignored exception on HbbTV 1.x devices, which is fine
  } catch (e) {
    // ignore
  }
  setKeyset(0x1+(regKeys?0x2+0x4+0x8+0x10:0));
}

function registerKeyEventListener(l) {
  document.addEventListener("keydown", function(e) {
    if (l(e.keyCode)) {
      e.preventDefault();
    }
  }, false);
}

function getAppMgr() {
  var app = null;
  try {
    app = document.getElementById("appmgr").getOwnerApplication(document);
  } catch (e) {
    // ignore
  }
  return app;
}

function setKeyset(mask) {
  var app;
  try {
    app = getAppMgr();
    app.privateData.keyset.setValue(mask);
  } catch (e) {
    // ignore
  }
}

function destroyApp() {
  var app;
  try {
    app = getAppMgr();
    app.destroyApplication();
  } catch (err1) {
    showStatus(0, "destroyApplication failed: "+err1);
  }
}
function runApp(appinfo) {
  var runAppInt = function() {
    var app;
    try {
      app = getAppMgr();
      app.createApplication("dvb://current.ait/"+appinfo.appid+(appinfo.params||""), false);
      destroyApp();
    } catch (err1) {
      showStatus(0, "createApplication failed: "+err1);
    }
  };
  if (!appinfo.sid) {
    runAppInt();
    return;
  }
  selectChannel(appinfo, runAppInt);
}
function selectChannel(chinfo, ondone) {
  var vid = document.getElementById("vid");
  var ch, lst, succ = false;
  try {
    lst = vid.getChannelConfig().channelList;
    ch = lst.getChannelByTriplet(settings.onid, settings.tsid, chinfo.sid);
  } catch (err1) {
    showStatus(0, "vid.getChannelByTriplet failed: "+err1);
    if (!GLOB.demo) {
      return;
    }
  }
  if (!ch && !GLOB.demo) {
    showStatus(0, "vid.getChannelByTriplet did not return any channel for "+settings.onid+"."+settings.tsid+"."+chinfo.sid);
    return;
  }
  vid.onChannelChangeSucceeded = function() {
    vid.onChannelChangeSucceeded = null;
    succ = true;
    if (ondone) {
      // wait for AIT
      setTimeout(ondone, 1000);
    }
  };
  try {
    vid.setChannel(ch, false);
    showInfo("setChannel "+settings.onid+"."+settings.tsid+"."+chinfo.sid+" called.");
  } catch (err2) {
    if (GLOB.demo) {
      setTimeout(vid.onChannelChangeSucceeded, 100);
    } else {
      showStatus(0, "vid.setChannel failed: "+err2);
    }
    return;
  }
  setTimeout(function() {
    if (!succ) {
      showStatus(0, "vid.setChannel failed: vid.onChannelChangeSucceeded was not called");
    }
  }, 5000);
}


function showStatus(succss, txt) {
  var p = document.createElement("p");
  if (txt) {
    txt = (""+txt).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  } else {
    txt = "";
  }
  if (succss===-1) {
    txt = "INFO: "+txt;
  } else if (succss===2) {
    txt = "MANUAL CHECK REQUIRED: "+txt;
    p.className = "statwarn";
  } else if (succss) {
    txt = "TEST PASS: "+txt;
    p.className = "statok";
  } else {
    txt = "TEST FAILED: "+txt;
    p.className = "statfail";
  }
  p.innerHTML = txt;
  GLOB.status.appendChild(p);
}

function showInfo(txt) {
  showStatus(-1, txt);
}

