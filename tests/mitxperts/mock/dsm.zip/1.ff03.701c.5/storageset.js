/*global initBase, initApp, showInfo, showStatus, selectChannel, destroyApp, settings, GLOB */

function switchBack() {
  showInfo("Switching back to LocalStorage-Get service to run final test...");
  try {
    document.getElementById("vid").bindToCurrentChannel();
  } catch (err2) {
    showStatus(0, "vid.bindToCurrentChannel() failed: "+err2);
    if (!GLOB.demo) {
      return;
    }
  }
  setTimeout(function() {
    selectChannel(settings.getDataApp, destroyApp);
  }, 3000);
}

function init() {
  initBase();
  initApp(false);
  showInfo("Checking call parameters...");
  try {
    var hash = ""+window.location.hash;
    if (hash.substring(0, 1)==="#") {
      hash = hash.substring(1);
    }
    if (hash!=="set") {
      switchBack();
      return;
    }
  } catch (err1) {
    showStatus(0, "Checking call parameters failed: "+err1);
    return;
  }
  try {
    localStorage.setItem('ardtest1', 'X1');
  } catch (err2) {
    showStatus(0, "localStorage.setItem failed: "+err2);
    return;
  }
  showInfo("Please go to standby, then wait 5 minutes for persistent storage to be written, then power-cycle your device.");
}

