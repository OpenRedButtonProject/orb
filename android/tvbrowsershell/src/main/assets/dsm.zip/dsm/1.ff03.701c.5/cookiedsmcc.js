/*global initBase, initApp, showInfo, showStatus */

function init() {
  initBase();
  initApp(false);
  showInfo("Checking cookieEnabled...");
  try {
    if ((typeof navigator.cookieEnabled)==="undefined") {
      showStatus(0, "navigator.cookieEnabled not defined");
      return;
    }
    if (!navigator.cookieEnabled) {
      showStatus(0, "navigator.cookieEnabled not set to true, please change device configuration to allow cookies");
      return;
    }
  } catch (err1) {
    showStatus(0, "Checking navigator.cookieEnabled failed: "+err1);
    return;
  }
  showStatus(1, "navigator.cookieEnabled set to true");
}

