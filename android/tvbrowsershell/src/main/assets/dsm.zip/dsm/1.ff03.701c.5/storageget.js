/*global initBase, initApp, showInfo, showStatus, registerKeyEventListener, runApp, destroyApp, settings, GLOB, VK_RED */

function init() {
  initBase();
  initApp(false);
  showInfo("Checking local storage...");
  try {
    if (localStorage.getItem('ardtest1')==='X1') {
      showStatus(1, "LocalStorage information found, press VK_RED to reset data");
      registerKeyEventListener(function(kc) {
        if (kc!==VK_RED) {
          return false;
        }
        localStorage.removeItem('ardtest1');
        destroyApp();
        return true;
      });
      return;
    }
  } catch (err1) {
    showStatus(0, "Checking localStorage failed: "+err1);
    return;
  }
  try {
    document.getElementById("vid").bindToCurrentChannel();
  } catch (err2) {
    showStatus(0, "vid.bindToCurrentChannel() failed: "+err2);
    if (!GLOB.demo) {
      return;
    }
  }
  showInfo("LocalStorage information not found, press VK_RED to set data");
  registerKeyEventListener(function(kc) {
    if (kc!==VK_RED) {
      return false;
    }
    showInfo("Launching setter app...");
    runApp(settings.setDataApp);
    return true;
  });
}

