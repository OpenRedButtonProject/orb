var releaseinfo = "1.0.1 (20190805)";
var settings = {
  "onid":1,
  "tsid":65290,
  "getDataApp": {"sid":28700, "appid":"13.101"},
  "setDataApp": {"sid":28701, "appid":"13.102", "params":"#set"}
};

